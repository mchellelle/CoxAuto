Coding Exercise Instructions
1. Open index.html in Edge or Chrome
2. Click "Get Results"